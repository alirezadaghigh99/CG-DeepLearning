
import os, json
from ast import literal_eval
import ast
current = "./"

import astor  

def extract_test_functions_from_file(file_path):
    """Extracts unit test functions as source code from a given Python file."""
    with open(file_path, 'r') as file:
        node = ast.parse(file.read())

    test_functions_code = []
    for func in [n for n in node.body if isinstance(n, ast.FunctionDef)]:
        if 'test' in func.name:
            # Convert the function node back to source code
            function_code = astor.to_source(func)
            test_functions_code.append(function_code.strip())
    
    return test_functions_code


count = 0



for name in os.listdir(current):
    # Open file
    if "test_extrator.py" in name:
        continue
    try:
        with open(os.path.join(current , name)) as f:
            print(f"Content of '{name}'")
            # Read content of file
            try:
                data = literal_eval(f.read())
                examples = []
                for d in data:
                    tests = extract_test_functions_from_file(f"../repo_test/{d}")
                    
                    for test in tests:
                        if len(test.split("\n"))< 10 or True:
                            
                            examples.append(test)
                    print(examples[0])
                count += len(examples)
               
            except Exception as e:
                print("error", e)
        
    except Exception as e:
        pass
print(count)
            


 
