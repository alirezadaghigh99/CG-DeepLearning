import unittest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset

class SimpleDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]

class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(10, 2)

    def forward(self, x):
        return self.fc(x)

class TestDeepLearningProject(unittest.TestCase):

    def setUp(self):
        self.model = SimpleModel()
        self.dataset = SimpleDataset(torch.randn(100, 10), torch.randint(0, 2, (100,)))
        self.dataloader = DataLoader(self.dataset, batch_size=32, shuffle=True)
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = optim.SGD(self.model.parameters(), lr=0.01)

    def test_dataset_loading(self):
        data, label = self.dataset[0]
        self.assertEqual(data.shape, (10,))
        self.assertIn(label.item(), [0, 1])

    def test_dataloader(self):
        batch = next(iter(self.dataloader))
        data, labels = batch
        self.assertEqual(data.shape, (32, 10))
        self.assertEqual(labels.shape, (32,))

    def test_model_shape(self):
        data, _ = next(iter(self.dataloader))
        output = self.model(data)
        self.assertEqual(output.shape, (32, 2))

    def test_model_shape_mismatch(self):
        with self.assertRaises(RuntimeError):
            wrong_shape_data = torch.randn(32, 5)  
            self.model(wrong_shape_data)

    def test_loss_computation(self):
        data, labels = next(iter(self.dataloader))
        outputs = self.model(data)
        loss = self.criterion(outputs, labels)
        self.assertGreater(loss.item(), 0)

    def test_optimizer_step(self):
        data, labels = next(iter(self.dataloader))
        outputs = self.model(data)
        loss = self.criterion(outputs, labels)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        for param in self.model.parameters():
            self.assertIsNotNone(param.grad)

    def test_model_save_and_load(self):
        torch.save(self.model.state_dict(), 'model.pth')
        new_model = SimpleModel()
        new_model.load_state_dict(torch.load('model.pth'))
        for param1, param2 in zip(self.model.parameters(), new_model.parameters()):
            self.assertTrue(torch.equal(param1, param2))

    def test_overfitting_on_small_batch(self):
        small_data = torch.randn(10, 10)
        small_labels = torch.randint(0, 2, (10,))
        for _ in range(100):  # Train for 100 iterations
            outputs = self.model(small_data)
            loss = self.criterion(outputs, small_labels)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
        self.assertLess(loss.item(), 0.1)

    def test_gradient_computation(self):
        data, labels = next(iter(self.dataloader))
        outputs = self.model(data)
        loss = self.criterion(outputs, labels)
        self.optimizer.zero_grad()
        loss.backward()
        for param in self.model.parameters():
            self.assertIsNotNone(param.grad)
            self.assertGreater(torch.norm(param.grad).item(), 0)

    def test_evaluation_mode(self):
        self.model.eval()
        with torch.no_grad():
            data, _ = next(iter(self.dataloader))
            output = self.model(data)
        self.assertEqual(output.shape, (32, 2))

if __name__ == '__main__':
    unittest.main()