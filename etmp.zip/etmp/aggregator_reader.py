import pandas as pd

df = pd.read_csv("data.csv")
for i in range(1, 10):
    count_filter = df[df[f'Called in functions with {i} calls'] > 4].shape[0]
    print(f"Number of functions called more than 4 times in functions with exactly {i} call:", count_filter)