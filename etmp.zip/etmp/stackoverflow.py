import requests
import time
from json_saver import save_dict_to_jsonl
api_key = '0Suv0nY5qR545T9YWrzuVQ(('
def fetch_questions(tag, site='stackoverflow', num_pages=6):
    """Fetch questions tagged with a specific tag from Stack Overflow and handle pagination."""
    all_questions = []
    for page in range(num_pages, 2 * num_pages + 1):
        print("page, ", page)
        time.sleep(2)
        url = f'https://api.stackexchange.com/2.3/questions'
        params = {
            'page': page,
            'pagesize': 100,
            'order': 'desc',
            'sort': 'creation',
            'tagged': tag,
            'site': site,
            'filter': 'withbody',
            'key': api_key
        }
        response = requests.get(url, params=params)
        try:
            response.raise_for_status()  # Raises an HTTPError for bad requests
            data = response.json()
            all_questions.extend(data['items'])
            if not data.get('has_more', False):  # Check if there are more pages
                break
        except requests.exceptions.HTTPError as e:
            print(f"HTTP error occurred: {e}")  # Print HTTP error message
            break
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data: {e}")  # Print any other request issues
            continue
    return all_questions


def fetch_accepted_answer(question_id, site='stackoverflow'):
    url = f'https://api.stackexchange.com/2.3/questions/{question_id}/answers'
    params = {
        'order': 'desc',
        'sort': 'votes',
        'site': site,
        'filter': 'withbody',
        'is_accepted': True,
        'key': api_key
    }
    max_retries = 5  # Maximum number of retries
    for attempt in range(max_retries):
        try:
            response = requests.get(url, params=params)
            time.sleep(1)
            response.raise_for_status()  # Will raise an exception for HTTP errors
            answers = response.json()
            for answer in answers.get('items', []):
                if answer.get('is_accepted'):
                    print("finally")
                    return answer
            return None  # No accepted answer found
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt+1} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(2**attempt)  # Exponential backoff
            else:
                print("Max retries exceeded")
                return None


def main():
    tag = 'deep-learning'  # Change to your desired tag
    num_pages = 7  # Define how many pages to fetch, adjust as necessary
    deep_learning_tags = [
    "tensorflow",
    "keras",
    "pytorch",
    "deep-learning",
    "neural-network",
    "convolutional-neural-networks",
    "nlp",
    "lstm",
    "gpu",
    "machine-learning",
    "image-recognition",
    "tensorflow2.0",
    "transfer-learning",
    "object-detection",
    "yolo"
]
    questions = fetch_questions(tag, num_pages=num_pages)
    count = 0
    for tag in deep_learning_tags:
        for question in questions:
            if question.get('is_answered') and question.get('accepted_answer_id'):
                accepted_answer = fetch_accepted_answer(question['question_id'])
                
                
                if accepted_answer:
                    count+= 1
                    link = question["link"]
                    answer = accepted_answer["body"]
                    title = question["title"]
                    q = question["body"]
                    data = {
                        "id": count,
                        "link": link,
                        "title": title,
                        "question": q,
                        "ansewr": answer
                    }
                    save_dict_to_jsonl(data, "stack_overflow.jsonl")
                print("-" * 80)
    print(count)
if __name__ == '__main__':
    main()
